import java.util.Scanner;
import java.time.LocalDate;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;

public class FarmersAlmanac 
{
	public static void main(String[] args) 
	{
		Scanner kb = new Scanner(System.in);
	    int userChoice=0;	    
	    do
	    {
	    	System.out.println("Please enter a number 1-6 for the action you wish to perform and press Enter:");
		    System.out.println("1. Add a new plant record");
		    System.out.println("2. Water a plant");
		    System.out.println("3. Replant something");
		    System.out.println("4. See when a plant was last watered");
		    System.out.println("5. See when something was last planted");
		    System.out.println("6. List all plant records");
		    System.out.println("7. Close Program");
		    userChoice = kb.nextInt(); kb.nextLine();		    
		    if(userChoice==1)
		    {
				System.out.println("What type of plant are you adding? (Tomato, Pepper, etc.)");
				
				addNewRecord(kb.nextLine());
		    }		    
		    else if(userChoice==2)
		    {
		    	System.out.println("Which plant did you just water?");
		    	String watered = kb.nextLine();
		    	if(findRecord(watered)==true)
		    	{
		    		updateWhenWatered(watered);
		    	}
		    	else
		    		System.out.println("Error: That plant record does not exist.");		    	
		    }		    
		    else if(userChoice==3)
		    {
		    	System.out.println("What did you just replant?");
		    	String replant = kb.nextLine();
		    	if(findRecord(replant)==true)
		    	{
		    		updateWhenPlanted(replant);
		    	}
		    	else
		    		System.out.println("Error: That plant record does not exist.");
		    }
		    else if(userChoice==4)
		    {
		    	System.out.println("Which plant?");
		    	String lastWatered = kb.nextLine();
		    	if(findRecord(lastWatered)==true)
		    	{
		    		System.out.println(getWhenWatered(lastWatered));
		    	}
		    	else
		    		System.out.println("Error: That plant record does not exist.");
		    }
		    else if(userChoice==5)
		    {
		        System.out.println("Which plant?");
		    	String lastPlanted = kb.nextLine();
		    	if(findRecord(lastPlanted)==true)
		    	{
		    		System.out.println(getWhenPlanted(lastPlanted));
		    	}
		    	else
		    		System.out.println("Error: That plant record does not exist.");
		    }
		    else if(userChoice==6)
		    {
		    	getRecords();
		        /*String[] recordsList = getRecords();
		        
		        for(int i=0;i<recordsList.length;i++)
			    {
			    	//System.out.println(recordsList[i] + "\n");
			    }*/
		    }
		    else if(userChoice==7)
		    {
		        System.out.println("Goodbye");kb.close();
		    }	
		    else
		    {
		    	System.out.println("That was not a valid option, please try again.");
		    }
	    }while(userChoice!=7);
	}
	
	private static void addNewRecord(String fileName)
	{
		File directory = new File("C:/Plant Records");
		if(directory.exists())
		{
			// If the directory already exists, move on to the next part of the method.
		}
		else
		{
			directory.mkdir();  // If the directory does not exist yet on the local drive, create it here.
		}
		
		File newFile = new File("C:/Plant Records/"+fileName+".txt");
		if(newFile.exists())
		{
			System.out.println("That record already exists. Please try another name.");
		}
		else
		{
			try
			{
				FileOutputStream fileWriter = new FileOutputStream(("C:/Plant Records/" + fileName + ".txt"));
				LocalDate date = LocalDate.now();
				fileWriter.write(fileName.getBytes());fileWriter.write("\n".getBytes());
				String fout1 = "Watered: " + date.getMonth() + "/" + date.getDayOfMonth() + "/" + date.getYear();
				fileWriter.write(fout1.getBytes());fileWriter.write("\n".getBytes());
				String fout2 = "Planted: " + date.getMonth() + "/" + date.getDayOfMonth() + "/" + date.getYear();
				fileWriter.write(fout2.getBytes());fileWriter.write("\n".getBytes());
	    		fileWriter.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
	    		System.out.println("Something didn't work there");
			}
		}		
	}
	
	private static boolean findRecord(String fileName)
	{
		boolean result = false;
		try
		{
			File record = new File("C:/Plant Records/"+fileName+".txt");
			if(record.exists())
			{
				result = true;
			}
			else
			{
				result = false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
    		System.out.println("Something didn't work there");
		}
		return result;
	}
	
	private static void updateWhenWatered(String fileName)
	{		
		try
		{
			File directory = new File("C:/Plant Records/" + fileName + ".txt");
			BufferedReader fileReader = new BufferedReader(new FileReader(directory));
			String tempName = fileReader.readLine();
			String tempWatered = fileReader.readLine();
			String tempPlanted = fileReader.readLine();fileReader.close();			
			LocalDate date = LocalDate.now();
			tempWatered = "Watered: " + date.getMonth() + "/" + date.getDayOfMonth() + "/" + date.getYear();
			FileOutputStream fileWriter = new FileOutputStream(("C:/Plant Records/" + fileName + ".txt"));
			fileWriter.write(tempName.getBytes());fileWriter.write("\n".getBytes());
			fileWriter.write(tempWatered.getBytes());fileWriter.write("\n".getBytes());
			fileWriter.write(tempPlanted.getBytes());fileWriter.write("\n".getBytes());
			fileWriter.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
    		System.out.println("Something didn't work there");
		}		
	}
	
	private static void updateWhenPlanted(String fileName)
	{		
		try
		{
			File directory = new File("C:/Plant Records/" + fileName + ".txt");
			BufferedReader fileReader = new BufferedReader(new FileReader(directory));
			LocalDate date = LocalDate.now();
			String tempName = fileReader.readLine();
			String tempWatered = fileReader.readLine();fileReader.close();			
			String tempPlanted = "Watered: " + date.getMonth() + "/" + date.getDayOfMonth() + "/" + date.getYear();
			FileOutputStream fileWriter = new FileOutputStream(("C:/Plant Records/" + fileName + ".txt"));
			fileWriter.write(tempName.getBytes());fileWriter.write("\n".getBytes());
			fileWriter.write(tempWatered.getBytes());fileWriter.write("\n".getBytes());
			fileWriter.write(tempPlanted.getBytes());fileWriter.write("\n".getBytes());
			fileWriter.close();			
		}
		catch(Exception e)
		{
			e.printStackTrace();
    		System.out.println("Something didn't work there");
		}
	}
	
	private static String getWhenWatered(String fileName)
	{
	    String lastWatered="";
	    try
		{
			File directory = new File("C:/Plant Records/" + fileName + ".txt");
			BufferedReader fileReader = new BufferedReader(new FileReader(directory));
			String tempName = fileReader.readLine();
			lastWatered = fileReader.readLine();fileReader.close();			
		}
		catch(Exception e)
		{
			e.printStackTrace();
    		System.out.println("Something didn't work there");
		}
	    return lastWatered;
	}
	
	private static String getWhenPlanted(String fileName)
	{
	    String lastPlanted="";
	    try
		{
			File directory = new File("C:/Plant Records/" + fileName + ".txt");
			BufferedReader fileReader = new BufferedReader(new FileReader(directory));
			String tempName = fileReader.readLine(); String tempWatered = fileReader.readLine(); lastPlanted = fileReader.readLine();fileReader.close();		
		}
		catch(Exception e)
		{
			e.printStackTrace();
    		System.out.println("Something didn't work there");
		}
	    return lastPlanted;
	}
	
	private static void getRecords()
	{
		File[] records = null;
	    try
		{
			File directory = new File("C:/Plant Records/");
			records = directory.listFiles();
		}
		catch(Exception e)
		{
			e.printStackTrace();
    		System.out.println("Something didn't work there");
		}
	    String[] recordsList = null;
	    for(int i=0;i<records.length;i++)
	    {
	    	recordsList = new String[records.length];
	    	String temp = "";
	    	recordsList[i] = records[i].getName();
	    	temp = recordsList[i];
	    	System.out.println(temp);
	    }
	}
}
